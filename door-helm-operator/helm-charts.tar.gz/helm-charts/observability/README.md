## AWS

> helm  upgrade -i monitoring ./ -n cloudoor-monitoring --set kubePrometheusStack.grafana.adminPassword=<password> --set lokistackaws.enabled=true --set lokistackaws.loki.config.storage_config.aws.bucketnames=<bucket_name> --set lokistackaws.accessKeyId=<accessKeyId> --set lokistackaws.secretAccessKey=<secretAccessKey> --set lokistackaws.loki.config.storage_config.aws.region=<region>
 
## GCP

> helm  upgrade -i monitoring  ./ -n cloudoor-monitoring --set kubePrometheusStack.grafana.adminPassword=<password> --set lokistackgcp.enabled=true --set lokistackgcp.loki.config.storage_config.gcs.bucket_name=<bucket_name> --set lokistackgcp.gcpCredentialsBase64=<key.jon in base64>

## Azure

> helm  upgrade -i monitoring ./ -n cloudoor-monitoring --set kubeprometheusstack.grafana.adminPassword=<password> --set lokistackazure.enabled=true --set lokistackazure.loki.config.storage_config.azure.container_name=<container_name> --set lokistackazure.loki.config.storage_config.azure.tenant_id=<tenant_id>  --set lokistackazure.loki.config.storage_config.azure.client_id="<client_id>" --set lokistackazure.loki.config.storage_config.azure.client_secret="<client_secret>"
